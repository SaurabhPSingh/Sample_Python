'use strict';

var apiLoginKey = '5KP3u95bQpv';
var transactionKey = '346HZ32z3fP4hTG2';

module.exports.apiLoginKey = apiLoginKey;
module.exports.transactionKey = transactionKey;