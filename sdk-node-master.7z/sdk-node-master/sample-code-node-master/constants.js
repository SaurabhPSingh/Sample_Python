'use strict';

module.exports.apiLoginKey = '5KP3u95bQpv';
module.exports.transactionKey = '346HZ32z3fP4hTG2';
