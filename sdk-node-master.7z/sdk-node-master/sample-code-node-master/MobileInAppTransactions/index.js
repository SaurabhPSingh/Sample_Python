'use strict';

module.exports = {
	createApplePayTransaction: require('./create-an-apple-pay-transaction.js').createApplePayTransaction
};
