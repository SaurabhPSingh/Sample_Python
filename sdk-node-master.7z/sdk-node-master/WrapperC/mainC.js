var fs = require('fs');
var csv=require('fast-csv');
var path = require('path');
global.projectRoot=path.resolve('./');

var sampleFile;

var ws = fs.createWriteStream(projectRoot+'/WrapperC/CSV_Files/outputfile.csv');
csv
   .write([['Test_Case_Id','API_Name','Result','Remarks']], {headers: true})
   .pipe(ws);

//csv.writeToPath(projectRoot+'/WrapperC/CSV_Files/outputfile.csv', [['Test_Case_Id','API_Name','Result','Remarks']])
//.on("finish", function(){});

fs.createReadStream(projectRoot+'/WrapperC/CSV_Files/driver.csv')
	.pipe(csv())
	.on('data',function(columns)
	{
		if(columns[2]=='1')
		{
			fileName=columns[1].replace(/([A-Z])/g, '-$1').toLowerCase().slice(1);
			sampleFile=require(projectRoot+'\\sample-code-node-master\\'+columns[0]+'\\'+fileName+'.js');
			callSampleCode(columns[1]);
		}
	})
	.on('end',function(data)
	{});
	
function callSampleCode(sampleName)
	{
	console.log(sampleName);
		let apiLoginId='to be put in later';
		let transactionKey='to be put in later';
		switch(sampleName)
		{
		case'CreateCustomerProfile':
			sampleFile.createCustomerProfile();
			break;

		case'CreateCustomerPaymentProfile':
			sampleFile.createCustomerProfile(apiLoginId,transactionKey);
			break;
			
		case'CreateCustomerProfileFromTransaction':
			sampleFile.createCustomerProfile(apiLoginId,transactionKey);
			break;
			
		case'CreateCustomerShippingAddress':
			sampleFile.createCustomerProfile(apiLoginId,transactionKey);
			break;
			
		case'DeleteCustomerPaymentProfile':
			sampleFile.createCustomerProfile(apiLoginId,transactionKey);
			break;
			
		case'DeleteCustomerProfile':
			sampleFile.createCustomerProfile(apiLoginId,transactionKey);
			break;
			
		case'DeleteCustomerShippingAddress':
			sampleFile.createCustomerProfile(apiLoginId,transactionKey);
			break;
			
		case'GetCustomerPaymentProfile':
			sampleFile.createCustomerProfile(apiLoginId,transactionKey);
			break;
			
		case'GetCustomerProfile':
			sampleFile.createCustomerProfile(apiLoginId,transactionKey);
			break;
			
		case'GetCustomerProfileIds':
			sampleFile.createCustomerProfile(apiLoginId,transactionKey);
			break;
			
		case'GetCustomerShippingAddress':
			sampleFile.createCustomerProfile(apiLoginId,transactionKey);
			break;
			
		case'GetHostedProfilePage':
			sampleFile.createCustomerProfile(apiLoginId,transactionKey);
			break;
			
		case'UpdateCustomerPaymentProfile':
			sampleFile.createCustomerProfile(apiLoginId,transactionKey);
			break;
	
		case'UpdateCustomerProfile':
			sampleFile.createCustomerProfile(apiLoginId,transactionKey);
			break;
			
		case'UpdateCustomerShippingAddress':
			sampleFile.createCustomerProfile(apiLoginId,transactionKey);
			break;
			
		default:
	        console.log('Not a valid sample code name');
		}
	
	}
