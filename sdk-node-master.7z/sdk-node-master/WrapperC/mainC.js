var fs = require('fs');
var csv=require('fast-csv');
var path = require('path');

//Node has a a global namespace object called global — anything
//that you attach to this object will be available everywhere in
//your app.

testRoot = path.resolve(__dirname);
global.projectRoot=path.resolve('./');

fs.createReadStream(projectRoot+'/WrapperC/CSV_Files/driver.csv')
	.pipe(csv())
	.on('data',function(columns)
	{
		if(columns[2]=='1')
		{
			callSampleCode(columns[1]);
		}
	})
	.on('end',function(data)
	{});
	
function callSampleCode(sampleName)
	{
	console.log(sampleName);
		let apiLoginId='to be put in later';
		let transactionKey='to be put in later';
		switch(sampleName)
		{
		case'':
		}
	
	}
