Generating classes from xsd
--------------------------------------
- use the pyxbgen script from PyXB
- run the following:
 python [path to pyxbgen] -u [link to xsd schema] -m [name of module to contain the classes]
- refer to generateObjectsFromXSD.bat in the scripts folder to see how it's used