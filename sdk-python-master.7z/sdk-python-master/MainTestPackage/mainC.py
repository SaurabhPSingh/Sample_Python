import csv
import sys,os
import re
sys.path.append(os.path.realpath('..')) #setting current path to current folder MainTestPackage and CSV_Files is inside.
with open('CSV_Files/output.csv', 'a', newline='') as csvfile:
    writer = csv.writer(csvfile, delimiter=',',quotechar='|', quoting=csv.QUOTE_MINIMAL)
    writer.writerow(["Test_Case_Id","Result","Comments"]);

with open('CSV_Files/driver.csv', newline='') as csvfile:  #current folder is MainTestPackage
    reader=csv.reader(csvfile, delimiter=',', quotechar='|')
    next(reader)
    for row in reader:
        if(row[2]=="1"):
            filename=re.sub(r"(\w)([A-Z])", r"\1-\2", row[1]);
            fileName=filename.lower();
            exec(open("../"+row[0]+"/"+fileName+".py").read())