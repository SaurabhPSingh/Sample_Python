import os, sys
import imp
import csv
import re
from authorizenet import apicontractsv1
from authorizenet.apicontrollers import *
constants = imp.load_source('modulename', 'constants.py')
import random

def create_customer_profile():

    merchantAuth = apicontractsv1.merchantAuthenticationType()
    merchantAuth.name = constants.apiLoginId
    merchantAuth.transactionKey = constants.transactionKey

    with open('CSV_Files/CreateCustomerProfile.csv', newline='') as csvfile:  # current folder is MainTestPackage
        reader = csv.reader(csvfile, delimiter=',', quotechar='|')
        next(reader)
        for row in reader:
            createCustomerProfile = apicontractsv1.createCustomerProfileRequest()
            createCustomerProfile.merchantAuthentication = merchantAuth
            createCustomerProfile.profile = apicontractsv1.customerProfileType(row[1] + str(random.randint(0, 10000)), row[2], row[3])
            tcId=row[0];
            controller = createCustomerProfileController(createCustomerProfile)
            controller.execute()

            response = controller.getresponse()
            with open('CSV_Files/output.csv', 'a', newline='') as csvfile:
                writer = csv.writer(csvfile, delimiter=',',
                                    quotechar='|', quoting=csv.QUOTE_MINIMAL)
                writer.writerow(["Test_Case_Id", "Result", "Comments"]);
                if (response.messages.resultCode=="Ok"):
                    print("Successfully created a customer profile with id: %s" % response.customerProfileId)
                    writer.writerow([tcId, "Passed", "Passed as response received"]);
                else:
                    print("Failed to create customer payment profile %s" % response.messages.message[0]['text'].text)
                    writer.writerow([tcId, "Failed", "Failed as response not correct."]);

            return response

if(os.path.basename(__file__) == os.path.basename(sys.argv[0])):
    create_customer_profile()
