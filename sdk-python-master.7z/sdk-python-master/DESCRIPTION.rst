# sdk-python    [![Build Status](https://magnum.travis-ci.com/egodolja/sdk-python.svg?token=9z5hnp59uHpbBpKa445s&branch=master)](https://magnum.travis-ci.com/egodolja/sdk-python)
Python SDK for the Authorize.Net API

Python - demo version commit
06/25/2015

Installations
--------------------------------------
- python 2.7
- pyxb 1.2.4
 *install python before pyxb 

 
Generating classes from xsd
--------------------------------------
- run generateObjectsFromXSD.bat script 


Testing Controllers
--------------------------------------
- each controller has its corresponding test
- results recorded in the log

Testing demoTest
--------------------------------------
- uncomment the commented out helper function in ARBCreateSubscriptionController to run demoTest
